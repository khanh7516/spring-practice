package khanh.todolistapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodolistAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodolistAppApplication.class, args);
	}

}
